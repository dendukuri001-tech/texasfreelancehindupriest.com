import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import heroImage from "@/assets/hero-priest.jpg";
import { Calendar, Flower2, Users, Heart } from "lucide-react";

const Index = () => {
  const services = [
    {
      icon: <Flower2 className="w-12 h-12 text-primary" />,
      title: "Wedding Ceremonies",
      description: "Traditional Hindu wedding rituals performed with authenticity and devotion.",
    },
    {
      icon: <Users className="w-12 h-12 text-primary" />,
      title: "Griha Pravesh",
      description: "Housewarming ceremonies to bless your new home with positive energy.",
    },
    {
      icon: <Heart className="w-12 h-12 text-primary" />,
      title: "Special Poojas",
      description: "Ganesh Pooja, Satyanarayan Pooja, Navagraha Pooja, and more.",
    },
    {
      icon: <Calendar className="w-12 h-12 text-primary" />,
      title: "Festival Services",
      description: "Celebrate Hindu festivals with traditional ceremonies and rituals.",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-hero">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 gap-12 items-center">
            <div className="relative">
              <img
                src={heroImage}
                alt="Hindu priest performing traditional pooja ceremony with diyas and flowers"
                className="rounded-2xl shadow-warm w-full h-auto"
              />
            </div>
            <div className="space-y-6">
              <div>
                <h1 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
                  Texas Hindu Priest
                </h1>
                <p className="text-2xl md:text-3xl text-muted-foreground mt-4 font-medium">
                  Venkata Bhavanarayana Dendukuri
                </p>
              </div>
              <div className="text-lg text-muted-foreground space-y-4">
                <p>
                  Venkata Bhavanarayana Dendukuri is a respected freelance Hindu priest serving the Texas area, known for his deep knowledge, devotion, and spiritual discipline. As a well-versed Veda Pandit with over twenty years of experience, he has performed countless Vedic rituals both inside temples and at devotees&apos; homes across the United States.
                </p>
                <p>
                  Trained extensively in traditional scriptures, he specializes in all Panchadasa Karmas, Homas, Samskaras, and a complete range of Hindu poojas, ensuring every ceremony is conducted with authenticity, precision, and sanctity.
                </p>
                <p>
                  Whether it is Griha Pravesham, Vivaham, Satyanarayana Vratham, Namakaranam, Annaprasana, Shraddha Karma, Lakshmi Pooja, or major Vedic homams, he brings unmatched expertise and spiritual depth to every ritual he performs.
                </p>
                <p>
                  With a warm, approachable nature and fluency in Sanskrit, Telugu, Hindi, and English, he offers guidance to families seeking auspicious beginnings, blessings, and traditional ceremonies rooted in ancient Vedic culture. Devotees appreciate his punctuality, discipline, and the peaceful spiritual atmosphere he creates during every ceremony.
                </p>
              </div>
              <div className="flex flex-wrap gap-4">
                <Button asChild size="lg" className="bg-gradient-primary shadow-warm text-lg">
                  <Link to="/services">Request Pooja Service</Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="text-lg">
                  <Link to="/gallery">View Gallery</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-4 bg-background/50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-foreground mb-4">Pooja Services Offered</h2>
            <p className="text-lg text-muted-foreground">Traditional Hindu ceremonies performed with devotion</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <Card key={index} className="bg-gradient-card border-border hover:shadow-warm transition-all duration-300">
                <CardContent className="p-6 text-center space-y-4">
                  <div className="flex justify-center">{service.icon}</div>
                  <h3 className="text-xl font-semibold text-foreground">{service.title}</h3>
                  <p className="text-muted-foreground">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-12">
            <Button asChild size="lg" className="bg-gradient-primary shadow-warm">
              <Link to="/services">Request a Service</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="text-4xl font-bold text-foreground">About Our Services</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              As a dedicated Hindu priest serving the Texas community, I bring years of experience in performing traditional poojas and ceremonies. Every ritual is conducted with proper Vedic procedures, ensuring authenticity and spiritual significance. Whether it's a wedding, housewarming, or special pooja, I am committed to making your ceremony meaningful and memorable.
            </p>
          </div>
        </div>
      </section>


      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <Card className="bg-gradient-primary border-0 shadow-warm">
            <CardContent className="p-12 text-center space-y-6">
              <h2 className="text-4xl font-bold text-primary-foreground">Ready to Book Your Pooja?</h2>
              <p className="text-lg text-primary-foreground/90 max-w-2xl mx-auto">
                Fill out our service request form and I will get back to you promptly to discuss your ceremony requirements.
              </p>
              <Button asChild size="lg" variant="secondary" className="shadow-lg">
                <Link to="/services">Book Now</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
