import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import weddingImage from "@/assets/gallery-wedding.jpg";
import ganeshImage from "@/assets/gallery-ganesh.jpg";
import grihaImage from "@/assets/gallery-griha.jpg";

const Gallery = () => {
  const galleryImages = [
    {
      src: weddingImage,
      title: "Traditional Hindu Wedding",
      description: "Beautiful wedding ceremony with sacred fire rituals",
    },
    {
      src: ganeshImage,
      title: "Ganesh Pooja",
      description: "Elaborate Ganesh Chaturthi celebration",
    },
    {
      src: grihaImage,
      title: "Griha Pravesh Ceremony",
      description: "Housewarming ceremony blessing a new home",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-hero">
      <Navigation />
      
      <main className="pt-32 pb-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold text-foreground mb-4">Gallery</h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              A glimpse of the beautiful ceremonies and poojas performed with devotion and tradition
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {galleryImages.map((image, index) => (
              <article key={index} className="group cursor-pointer">
                <div className="overflow-hidden rounded-2xl shadow-card hover:shadow-warm transition-all duration-300">
                  <img
                    src={image.src}
                    alt={image.description}
                    className="w-full h-80 object-cover transform group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="mt-4 space-y-2">
                  <h3 className="text-xl font-semibold text-foreground">{image.title}</h3>
                  <p className="text-muted-foreground">{image.description}</p>
                </div>
              </article>
            ))}
          </div>

          <div className="mt-16 text-center">
            <p className="text-lg text-muted-foreground mb-6">
              More photos from recent ceremonies will be added regularly
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Gallery;
