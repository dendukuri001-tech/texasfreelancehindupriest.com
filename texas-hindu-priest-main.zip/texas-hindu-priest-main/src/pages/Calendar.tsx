import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { useState } from "react";
import { format } from "date-fns";

const Calendar = () => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  const upcomingEvents = [
    {
      date: "2024-01-15",
      title: "Makar Sankranti",
      description: "Festival of harvest and new beginnings",
    },
    {
      date: "2024-01-26",
      title: "Republic Day Pooja",
      description: "Special pooja for Republic Day celebrations",
    },
    {
      date: "2024-02-14",
      title: "Maha Shivaratri",
      description: "Great night of Lord Shiva worship",
    },
    {
      date: "2024-03-08",
      title: "Holi",
      description: "Festival of colors and spring",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-hero">
      <Navigation />
      
      <main className="pt-32 pb-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold text-foreground mb-4">Calendar & Availability</h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Check upcoming Hindu festivals and my availability for ceremonies
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="shadow-warm bg-gradient-card border-border">
              <CardHeader>
                <CardTitle className="text-2xl">Select a Date</CardTitle>
                <CardDescription>Choose a date to check availability or view events</CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <CalendarComponent
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border border-border pointer-events-auto"
                />
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card className="shadow-warm bg-gradient-card border-border">
                <CardHeader>
                  <CardTitle className="text-2xl">Selected Date</CardTitle>
                  <CardDescription>
                    {selectedDate ? format(selectedDate, "PPPP") : "No date selected"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    To check availability for this date or to schedule a ceremony, please submit a service request through our Request Pooja page.
                  </p>
                </CardContent>
              </Card>

              <Card className="shadow-warm bg-gradient-card border-border">
                <CardHeader>
                  <CardTitle className="text-2xl">Upcoming Hindu Festivals</CardTitle>
                  <CardDescription>Important dates for traditional ceremonies</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-4">
                    {upcomingEvents.map((event, index) => (
                      <li key={index} className="border-l-4 border-primary pl-4 py-2">
                        <time className="text-sm font-medium text-primary">
                          {format(new Date(event.date), "MMMM d, yyyy")}
                        </time>
                        <h3 className="text-lg font-semibold text-foreground mt-1">{event.title}</h3>
                        <p className="text-muted-foreground text-sm">{event.description}</p>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          <Card className="mt-8 shadow-warm bg-gradient-primary border-0">
            <CardContent className="p-8 text-center">
              <h2 className="text-2xl font-bold text-primary-foreground mb-4">
                Need to Book a Ceremony?
              </h2>
              <p className="text-primary-foreground/90 mb-6">
                Submit a service request and I will get back to you with availability and details
              </p>
              <a
                href="/services"
                className="inline-flex items-center justify-center rounded-lg bg-background text-foreground px-6 py-3 font-medium shadow-lg hover:bg-background/90 transition-colors"
              >
                Request Service
              </a>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Calendar;
