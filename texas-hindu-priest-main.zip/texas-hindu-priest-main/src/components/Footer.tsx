import { Mail, Phone, MapPin, MessageCircle } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-card border-t border-border mt-20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4 bg-gradient-primary bg-clip-text text-transparent">
              Texas Hindu Priest
            </h3>
            <p className="text-muted-foreground">
              Professional Hindu priest services in Texas. Performing traditional poojas and ceremonies with devotion and authenticity.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-foreground">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a href="/" className="text-muted-foreground hover:text-primary transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="/services" className="text-muted-foreground hover:text-primary transition-colors">
                  Request Pooja
                </a>
              </li>
              <li>
                <a href="/gallery" className="text-muted-foreground hover:text-primary transition-colors">
                  Gallery
                </a>
              </li>
              <li>
                <a href="/calendar" className="text-muted-foreground hover:text-primary transition-colors">
                  Calendar
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-foreground">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-center space-x-2 text-muted-foreground">
                <MapPin size={18} className="text-primary flex-shrink-0" />
                <span>Texas, USA</span>
              </li>
              <li>
                <a 
                  href="tel:+19785589099" 
                  className="flex items-center space-x-2 text-muted-foreground hover:text-primary transition-colors"
                >
                  <Phone size={18} className="text-primary flex-shrink-0" />
                  <span>+1 (978) 558-9099</span>
                </a>
              </li>
              <li>
                <a 
                  href="mailto:venkatabdendukuri@gmail.com" 
                  className="flex items-center space-x-2 text-muted-foreground hover:text-primary transition-colors"
                >
                  <Mail size={18} className="text-primary flex-shrink-0" />
                  <span>venkatabdendukuri@gmail.com</span>
                </a>
              </li>
              <li>
                <a 
                  href="https://wa.me/19785589099" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 text-muted-foreground hover:text-primary transition-colors"
                >
                  <MessageCircle size={18} className="text-primary flex-shrink-0" />
                  <span>WhatsApp</span>
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Texas Freelance Hindu Priest. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
